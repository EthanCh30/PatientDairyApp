const apiUrl = 'http://localhost/staff.php';  // 替换成你的后端API URL

// Function to fetch patient data from the backend
async function fetchPatientData() {
    try {
        const response = await fetch(apiUrl);
        const data = await response.json();

        const tableBody = document.getElementById('patient-table-body');
        tableBody.innerHTML = ''; // Clear existing data
        
        // Iterate over each patient record and insert rows into the table
        data.forEach(patient => {
            const row = document.createElement('tr');

            row.innerHTML = `
                <td>${patient.name}</td>
                <td>${patient.height}</td>
                <td>${patient.weight}</td>
                <td>${patient.age}</td>
                <td>${patient.gender}</td>
            `;
            tableBody.appendChild(row);
        });

        // Make the details window visible after loading data
        document.getElementById('details-window').hidden = false;
    } catch (error) {
        console.error('Error fetching patient data:', error);
    }
}

// Call the function to fetch data when the page loads
window.onload = fetchPatientData;
